package notepadeditor;

import java.awt.Color;
import java.awt.Font;
import java.awt.GraphicsEnvironment;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.print.PageFormat;
import java.awt.print.PrinterException;
import java.awt.print.PrinterJob;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.time.LocalDateTime;
import javafx.util.converter.LocalDateTimeStringConverter;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBoxMenuItem;
import javax.swing.JColorChooser;
import javax.swing.JComboBox;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.KeyStroke;
import javax.swing.UIManager;

public class Notepad implements ActionListener {

    JFrame jf, replaceframe, fontframe, helpframe;
    JMenuBar menubar;
    JMenu file, edit, format, help;
    JMenuItem neww, new_window, open, save, save_as, page_setup, print, exit, cut, copy, paste, replace, date_time, font, font_color, textarea_color, query_feedback;
    JTextArea text_area, help_area;
    String title = "Untitled - Notepad", iconpath = "E:\\NetBeansProjects\\NotepadEditor\\src\\img\\icon.png";
    File f;
    JLabel jl1, jl2, ff1, fs1, fs2, hlp;
    JTextField jt1, jt2;
    JButton jb1, ok, submit;
    JComboBox cb_font_families, cb_font_style, cb_font_size;
    JCheckBoxMenuItem word_wrap;

    public Notepad() {
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception e) {
            System.out.println(e);
        }
        ImageIcon imgicon = new ImageIcon(iconpath);
        jf = new JFrame(title);
        jf.setIconImage(imgicon.getImage());
        jf.setSize(570, 370);
        jf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        jf.setLocationRelativeTo(jf);

        menubar = new JMenuBar();

        // File Menu Bar start
        file = new JMenu("File");

        neww = new JMenuItem("New");
        neww.addActionListener(this);
        neww.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_N, ActionEvent.CTRL_MASK));
        file.add(neww);

        new_window = new JMenuItem("New Window");
        new_window.addActionListener(this);
        new_window.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_N, java.awt.Event.CTRL_MASK | java.awt.Event.SHIFT_MASK));
        file.add(new_window);

        open = new JMenuItem("Open...");
        open.addActionListener(this);
        open.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_O, ActionEvent.CTRL_MASK));
        file.add(open);

        save = new JMenuItem("Save");
        save.addActionListener(this);
        save.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_S, ActionEvent.CTRL_MASK));
        file.add(save);

        save_as = new JMenuItem("Save As...");
        save_as.addActionListener(this);
        save_as.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_S, java.awt.Event.CTRL_MASK | java.awt.Event.SHIFT_MASK));
        file.add(save_as);

        file.addSeparator();

        page_setup = new JMenuItem("Page Setup...");
        page_setup.addActionListener(this);
        file.add(page_setup);

        print = new JMenuItem("Print...");
        print.addActionListener(this);
        print.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_P, ActionEvent.CTRL_MASK));
        file.add(print);

        file.addSeparator();

        exit = new JMenuItem("Exit");
        exit.addActionListener(this);
        file.add(exit);

        menubar.add(file);
        // File Menu Bar end

        // Edit Menu Bar start
        edit = new JMenu("Edit");

        cut = new JMenuItem("Cut");
        cut.addActionListener(this);
        cut.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_X, ActionEvent.CTRL_MASK));
        edit.add(cut);

        copy = new JMenuItem("Copy");
        copy.addActionListener(this);
        copy.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_C, ActionEvent.CTRL_MASK));
        edit.add(copy);

        paste = new JMenuItem("Paste");
        paste.addActionListener(this);
        paste.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_V, ActionEvent.CTRL_MASK));
        edit.add(paste);

        edit.addSeparator();

        replace = new JMenuItem("Replace");
        replace.addActionListener(this);
        replace.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_H, ActionEvent.CTRL_MASK));
        edit.add(replace);

        edit.addSeparator();

        date_time = new JMenuItem("Time/Date");
        date_time.addActionListener(this);
        date_time.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_F5, 0));
        edit.add(date_time);

        menubar.add(edit);
        // Edit Menu Bar end

        // Format Menu Bar start
        format = new JMenu("Format");

        word_wrap = new JCheckBoxMenuItem("Word Wrap");
        word_wrap.addActionListener(this);
        format.add(word_wrap);

        font = new JMenuItem("Font...");
        font.addActionListener(this);
        format.add(font);

        format.addSeparator();

        font_color = new JMenuItem("Font Color");
        font_color.addActionListener(this);
        format.add(font_color);

        textarea_color = new JMenuItem("Textarea Color");
        textarea_color.addActionListener(this);
        format.add(textarea_color);

        menubar.add(format);
        // Format Menu Bar end

        // Help Menu Bar start
        help = new JMenu("Help");
        query_feedback = new JMenuItem("Query/Feedback");
        query_feedback.addActionListener(this);
        help.add(query_feedback);

        menubar.add(help);
        // Help Menu Bar end

        jf.setJMenuBar(menubar);

        text_area = new JTextArea();
        JScrollPane scroll_pane = new JScrollPane(text_area);
        scroll_pane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        scroll_pane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
        jf.add(scroll_pane);

        jf.setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == neww) {
            newNotepad();
        }
        if (e.getSource() == new_window) {
            new Notepad();
        }
        if (e.getSource() == open) {
            open();
        }
        if (e.getSource() == save) {
            save();
        }
        if (e.getSource() == save_as) {
            saveAs();
        }
        if (e.getSource() == page_setup) {
            pageSetup();
        }
        if (e.getSource() == print) {
            print();
        }
        if (e.getSource() == exit) {
            System.exit(0);
        }
        if (e.getSource() == cut) {
            text_area.cut();
        }
        if (e.getSource() == copy) {
            text_area.copy();
        }
        if (e.getSource() == paste) {
            text_area.paste();
        }
        if (e.getSource() == replace) {
            replaceFrame();
        }
        if (e.getSource() == jb1) {
            replace();
        }
        if (e.getSource() == date_time) {
            dateTime();
        }
        if (e.getSource() == word_wrap) {
            boolean b = word_wrap.getState();
            text_area.setLineWrap(b);
        }
        if (e.getSource() == font) {
            openFontFrame();
        }
        if (e.getSource() == font_color) {
            setFontColor();
        }
        if (e.getSource() == textarea_color) {
            setTextAreaColor();
        }
        if (e.getSource() == ok) {
            setFontToNotepad();
        }
        if (e.getSource() == query_feedback) {
            help();
        }
        if (e.getSource() == submit) {
            submit();
        }
    }

    public void newNotepad() {
        String text = text_area.getText();
        if (!text.equals("")) {
            int i = JOptionPane.showConfirmDialog(jf, "Do you want to save changes to Untitled?");
            if (i == 0) {
                saveAs();
                if (!jf.getTitle().equals(title)) {
                    setTitle(title);
                    text_area.setText("");
                }
            } else if (i == 1) {
                text_area.setText("");
            }
        }
    }

    public void saveAs() {
        try {
            JFileChooser file_chooser = new JFileChooser();
            int i = file_chooser.showSaveDialog(jf);
//            System.out.println(i);
            if (i == 0) {
                String text = text_area.getText();
                byte[] b = text.getBytes();
                f = file_chooser.getSelectedFile();
                FileOutputStream fos = new FileOutputStream(f);
                fos.write(b);
//                System.out.println(f.getName());
                setTitle(f.getName());
                fos.close();
            }
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public void open() {
        try {
            JFileChooser fileChooser = new JFileChooser();
            int i = fileChooser.showOpenDialog(jf);
//            System.out.println(i);
            if (i == 0) {
                f = fileChooser.getSelectedFile();
                text_area.setText("");
                FileInputStream fis = new FileInputStream(f);
                int j;
                while ((j = fis.read()) != -1) {

                    text_area.append(String.valueOf((char) j));
                }
                setTitle(f.getName());
                fis.close();
            }
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public void save() {
        if (jf.getTitle().equals(title)) {
            saveAs();
        } else {
            try {
                String text = text_area.getText();
                byte[] b = text.getBytes();
                FileOutputStream fos = new FileOutputStream(f);
                fos.write(b);
            } catch (Exception e) {
                System.out.println(e);
            }
        }
    }

    public void pageSetup() {
        PrinterJob pj = PrinterJob.getPrinterJob();
        PageFormat pf = pj.pageDialog(pj.defaultPage());
    }

    public void print() {
        PrinterJob pj = PrinterJob.getPrinterJob();
        if (pj.printDialog()) {
            try {
                pj.print();
            } catch (PrinterException exc) {
                System.out.println(exc);
            }
        }
    }

    public void replaceFrame() {
        replaceframe = new JFrame("Replace");
        replaceframe.setSize(500, 300);
        replaceframe.setLayout(null);
        replaceframe.setLocationRelativeTo(replaceframe);

        jl1 = new JLabel("Find What: ");
        jl1.setBounds(50, 50, 100, 50);
        replaceframe.add(jl1);

        jt1 = new JTextField();
        jt1.setBounds(170, 55, 200, 40);
        replaceframe.add(jt1);

        jl2 = new JLabel("Replace With: ");
        jl2.setBounds(50, 100, 100, 50);
        replaceframe.add(jl2);

        jt2 = new JTextField();
        jt2.setBounds(170, 105, 200, 40);
        replaceframe.add(jt2);

        jb1 = new JButton("Replace");
        jb1.addActionListener(this);
        jb1.setBounds(225, 170, 100, 50);
        replaceframe.add(jb1);

        replaceframe.setVisible(true);
    }

    public void replace() {
        String find_what = jt1.getText();
        String replace_with = jt2.getText();
        String text = text_area.getText();
        String new_text = text.replace(find_what, replace_with);
        text_area.setText(new_text);

        replaceframe.setVisible(false);
    }

    public void dateTime() {
        LocalDateTimeStringConverter ldt = new LocalDateTimeStringConverter();
        String time_date = ldt.toString(LocalDateTime.now());
        text_area.append(time_date);
    }

    public void openFontFrame() {
        fontframe = new JFrame("Font");
        fontframe.setSize(500, 400);
        fontframe.setLayout(null);
        fontframe.setLocationRelativeTo(fontframe);

        ff1 = new JLabel("Font: ");
        ff1.setBounds(50, 25, 50, 10);
        fontframe.add(ff1);

        fs1 = new JLabel("Font Style: ");
        fs1.setBounds(210, 25, 80, 15);
        fontframe.add(fs1);

        fs2 = new JLabel("Font Size: ");
        fs2.setBounds(350, 25, 80, 15);
        fontframe.add(fs2);

        GraphicsEnvironment ge = GraphicsEnvironment.getLocalGraphicsEnvironment();
        String[] font_families = ge.getAvailableFontFamilyNames();
        cb_font_families = new JComboBox(font_families);
        cb_font_families.setBounds(50, 50, 150, 30);
        fontframe.add(cb_font_families);

        String[] font_style = {"Plain", "Italic", "Bold", "Bold Italic"};
        cb_font_style = new JComboBox(font_style);
        cb_font_style.setBounds(210, 50, 130, 30);
        fontframe.add(cb_font_style);

        Integer[] font_size = {8, 9, 10, 11, 12, 14, 16, 18, 20, 22, 24, 26, 28, 36, 48, 72};
        cb_font_size = new JComboBox(font_size);
        cb_font_size.setBounds(350, 50, 80, 30);
        fontframe.add(cb_font_size);

        ok = new JButton("OK");
        ok.setBounds(200, 250, 100, 50);
        ok.addActionListener(this);
        fontframe.add(ok);

        fontframe.setVisible(true);
    }

    public void setFontToNotepad() {
        String font_family = (String) cb_font_families.getSelectedItem();
        String font_style = (String) cb_font_style.getSelectedItem();
        Integer font_size = (Integer) cb_font_size.getSelectedItem();

        int font_stylee = 0;
        if (font_style.equals("Plain")) {
            font_stylee = Font.PLAIN;
        } else if (font_style.equals("Italic")) {
            font_stylee = Font.ITALIC;
        } else if (font_style.equals("Bold")) {
            font_stylee = Font.BOLD;
        } else if (font_style.equals("Bold Italic")) {
            font_stylee = Font.BOLD | Font.ITALIC;
        }

        Font f = new Font(font_family, font_stylee, font_size);
        text_area.setFont(f);

        fontframe.setVisible(false);
    }

    public void setFontColor() {
        Color c = JColorChooser.showDialog(jf, "Select Font Color", Color.BLACK);
        text_area.setForeground(c);
    }

    public void setTextAreaColor() {
        Color c = JColorChooser.showDialog(jf, "Select Font Color", Color.WHITE);
        text_area.setBackground(c);
    }

    public void help() {
        helpframe = new JFrame("Help");
        helpframe.setSize(500, 300);
        helpframe.setLocationRelativeTo(jf);
        helpframe.setLayout(null);

        hlp = new JLabel("Write query/feedback: ");
        hlp.setBounds(50, 50, 200, 50);
        helpframe.add(hlp);

        help_area = new JTextArea();
        help_area.setBounds(200, 50, 200, 100);
        helpframe.add(help_area);

        submit = new JButton("Submit");
        submit.setBounds(240, 180, 100, 30);
        submit.addActionListener(this);
        helpframe.add(submit);

        helpframe.setVisible(true);
    }

    public void submit() {
        String text = help_area.getText();
        if (!text.equals("")) {
            JOptionPane.showMessageDialog(jf, "Your Query/Feedback Submitted Successfully..");
            helpframe.setVisible(false);
        }
    }

    public void setTitle(String title) {
        jf.setTitle(title);
    }
}
