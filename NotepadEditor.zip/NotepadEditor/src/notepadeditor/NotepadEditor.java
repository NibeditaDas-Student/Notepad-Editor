package notepadeditor;

public class NotepadEditor {
    public static void main(String[] args) {
        new Notepad();
    }
}
